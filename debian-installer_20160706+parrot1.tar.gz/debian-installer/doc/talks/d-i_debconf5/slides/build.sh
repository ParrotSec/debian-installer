#!/bin/sh
pdflatex d-i_debconf5.tex
