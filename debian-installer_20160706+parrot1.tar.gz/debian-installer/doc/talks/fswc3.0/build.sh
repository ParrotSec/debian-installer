#!/bin/sh
pdflatex g-i_workmeeting.tex
