#!/bin/sh
pdflatex *.tex
pdflatex *.tex
