#!/bin/sh
pdflatex d-i_qa.tex
