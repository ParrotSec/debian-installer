#!/bin/sh
pdflatex d-i_debconf7.tex
